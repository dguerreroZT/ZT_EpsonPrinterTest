(function(){
	var fs = require('fs');
	var os = require( 'os' );

	this.getConnectionString = function(){
		var strConn
		strConn = {
			
			user:"", 		   /// <- Usuario
			password: "",  	  /// <- Password
			server: "",		 /// <- Servidor SQL
			database: "",  	///<- Nombre Base de Datos
			
			options: {encrypt: true }

		}

		if (strConn.server == ""){
			console.log("\x1b[31m No se han configurado los datos de conexión en el archivo config.js  \x1b[0m")
		}

		return strConn
	}

	/*
	this.https = {
	  key: fs.readFileSync('cert/localhost.key'),
	  cert: fs.readFileSync('cert/localhost.crt'),
	  passphrase: 'Zafiro2016'
	}
	*/


	//// Se obtiene la IP Automaticamente
	
	var ni = os.networkInterfaces( );
	var ipv4 = ni.Ethernet.find(function(con){return(con.family == 'IPv4')}) 
	var local_IP

	if(ipv4){
		local_IP = ipv4.address
	}
	else{
		local_IP = "localhost"  //// <- Cambiar aqui si no se puede obtener IP Automaticamente 
		console.log("\x1b[33m No se pudo obtener IP Automaticamente, se usa " + local_IP + "  \x1b[0m")
	}

	
	this.serverConfig = { 
		host: local_IP,
	    port: 8000
	    /*,
	    tls: this.https,
	    routes:{cors:true}
	    */
	}


}).call(this)