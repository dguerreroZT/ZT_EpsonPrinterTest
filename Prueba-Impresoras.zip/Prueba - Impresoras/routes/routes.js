(function(){
	const Path = require('path');

	this.addRoutes = function(server){
		// Prueba de impresora no necesita archivos dependientes

	}
}).call(this)