(function(){

	const builder = require('xmlbuilder');

	this.TransactionMethods = function (){
		//transaction: new sql.Transaction(),
		var that = this
		this.errorFound = false
		this.errorCatch = function (err) {
			that.errorFound = true
			console.log(err)
		}
		this.transactionDone = function(){
			if(that.errorFound){
				that.transaction.rollback()
				that.callback({d:{OK:false}})
			}else{
				that.transaction.commit(function (err){
					if(!err){
						that.callback({d:{OK:true}})	
					}else{
						if(err.code != 'EREQINPROG'){
							that.callback({d:{OK:false}})	
							console.log(that.lastRequest)
							console.log(err)
						}
					}
				})
			}
		}
	
	}

	this.convertArray = function ( arrToConvert ) {
		function flatten(arr) {
		  return arr.reduce(function (flat, toFlatten) {
		    return flat.concat(Array.isArray(toFlatten) ? flatten(toFlatten) : toFlatten);
		  }, []);
		}

		return flatten(arrToConvert);
	}

	this.filterFunction = function ( filterData, tableName, pageNumber, isGrs, isWhere ) {
		var grsString = "";
    	if(isWhere) grsString += " AND ("; else grsString += " WHERE (";


    	for(var i=0; i<filterData.length; i+=4){
    		var columnName = filterData[i];   //Nombre de la columna a filtrar
    		var comparator = filterData[i+1]; //Tiene el valor de comparación, ya sea simbolo o texto ej: contains, <>, etc
    		var filterText = filterData[i+2]; //Texto a filtrar

    		var dateRegEx = /([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}:){2}[09]{2}\.[09]{3}Z/g
			var rgxResult = dateRegEx.exec(filterText)
    		if (rgxResult){
    			filterText = rgxResult[1] + '' + rgxResult[2] + '' + rgxResult[3];
    		}

    		var operator   = filterData[i+3]; //Operador and/or

    		if(comparator == "contains" || comparator == "notcontains" || comparator == "startswith" || comparator == "endswith"){
    			if(comparator == "contains") grsString += "(" + columnName + " LIKE '%" + filterText + "%')";
    			if(comparator == "notcontains") grsString += "(" + columnName + " NOT LIKE '%" + filterText + "%')";
    			if(comparator == "startswith") grsString += "(" + columnName + " LIKE '" + filterText + "%')";
    			if(comparator == "endswith") grsString += "(" + columnName + " LIKE '%" + filterText + "')";
    		}
			else grsString += "(" + columnName + " " + comparator + " '" + filterText + "')";		
			if((i+3) != filterData.length) grsString += " " + operator + " ";
    	}
		return grsString;
	}

	this.getLookupData = function(data){
		for(var i=0; i<data.length; i++){
			var currentData = data[i];
			for(var key in currentData){
				currentValue = currentData[key];
				if(typeof currentValue == "string" && currentValue.indexOf("<tag>") > -1){
					currentValue = currentValue.slice(5, currentValue.length).split(",");
					for(var num = 0; num<currentValue.length; num++){
						console.log(currentValue[num])
						if(Number(currentValue[num]) > 0) currentValue[num] = Number(currentValue[num]);
					}
					currentData[key] = currentValue;
				}
			}
		}
    	/*$.ajax({
    		type: "POST",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            url: model.urlws + model.webMethods.lookup,
            data: parameters,
            async: false,
            success: function(data){
        		var rows = data.d;
        		targetModel[targetProperty] = rows;
            }
    	})*/
    	return data;
    }

    this.xmlBuild = function(data) {

		var noChange = true;

		var xml = builder.create('DS');

		

		for(var i=0; i<data.length; i++){

			currentData = data[i];

			if(currentData.rowControl != "NONE"){

				noChange = false;

				var item = xml.ele('E');

				for(var key in currentData)

				{

					if(!(currentData[key] == null)){

			  			item.att(key, currentData[key]);

					}

				}

			}

		}



		if(noChange) xml = null;

		return xml;

	}



}).call(this)