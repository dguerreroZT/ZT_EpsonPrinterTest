(function(){
	var fs = require('fs');
	var os = require( 'os' );

	this.getConnectionString = function(){
		var strConn
		strConn = {
			
			user:"",
			password: "",  /// <- Password
			server: "",
			database: "", 
			/*
			
			*/

			options: {
		        encrypt: true // Use this if you're on Windows Azure 
		    }

		}

		return strConn
	}

	this.https = {
	  key: fs.readFileSync('cert/localhost.key'),
	  cert: fs.readFileSync('cert/localhost.crt'),
	  passphrase: 'Zafiro2016'
	}


	//// Se obtiene la IP Automaticamente
	
	var ni = os.networkInterfaces( );
	var ipv4 = ni.Ethernet.find(function(con){return(con.family == 'IPv4')}) 
	var local_IP

	if(ipv4){
		local_IP = ipv4.address
	}
	else{
		local_IP = "localhost" 
		console.log("No se pudo obtener IP Automaticamente, se usa " + local_IP)
	}

	//local_IP = "localhost" 
	
	this.serverConfig = { 
		host: local_IP,
	    port: 8000
	    /*,
	    tls: this.https,
	     
	    */
	}


}).call(this)