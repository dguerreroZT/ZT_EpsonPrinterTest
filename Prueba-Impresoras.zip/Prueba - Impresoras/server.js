'use strict';

const Path = require('path');
const Hapi = require('hapi');

const routes = require('./routes/routes.js');
const serverConfig = require('./config.js').serverConfig;
const connectionString = require('./config.js').getConnectionString();
//const localtunnel = require('localtunnel');

const server = new Hapi.Server();


/////var tunnel = localtunnel(serverConfig.port, function(err, tunnel) {
/////    if (err) {
/////        console.log("Tunnel Error - ", err) 
/////        return
/////    }
/////
/////    // the assigned public url for your tunnel
/////    // i.e. https://abcdefgjhij.localtunnel.me
/////    console.log(tunnel.url)
/////    //serverConfig.host = tunnel.url


    // Se inicia la conexion del server
    server.connection(serverConfig);

    // Se configura el server
    server.register(require('inert'), function(err){

        if (err) {
            throw err;
        }

       server.route({
            method: 'GET',
             path: '/{param*}',
                handler: {
                directory: {
                    path: 'public',
                    listing: true
                }
            },
            config: {
                state: {
                    parse: false, // parse and store in request.state
                    failAction: 'ignore' // may also be 'ignore' or 'log'
                }
            }
        });



        // Add the route
        server.route({
            method: 'POST',
            path:'/hello', 
            handler: function (request, reply) {

                return reply('hello world');
            }
        });

        server.route({
            method: 'POST',
            path:'/log', 
            handler: function (request, reply) {
                console.log(request.payload.msg)
                return reply({ok:true,data:request.payload.msg});
            }
        });

        server.route({
            method: 'GET',
            path:'/getServerIP', 
            handler: function (request, reply) {

                return reply(server.info.uri + '/');
                //return reply(tunnel.url + '/');
            }
        });

        /// Se agregan los metodos para acceder a la base de datos
        routes.addRoutes(server);

        // Start the server
        server.start((err) => {

            if (err) {
                throw err;
            }
            console.log('Servidor iniciado correctamente:', server.info.uri);
        });

    });


///// //    tunnel.close()
///// });
///// 
///// tunnel.on('close', function() {
/////     console.log("tunnels are closed")
///// });
///// 